<?php

//Akses Database
require '../config/koneksi.php';

function TanggalIndo($date){
	$BulanIndo = array("Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember");
 
	$tahun = substr($date, 0, 4);
	$bulan = substr($date, 5, 2);
	$tgl   = substr($date, 8, 2);
 
	$result = $tgl . " " . $BulanIndo[(int)$bulan-1] . " ". $tahun;		
	return($result);
}

$response = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	
	//Mengambil Data
	$tanggal = $_POST['tanggal'];

	//Simpan ke Database
	$query = mysqli_query($koneksi,"SELECT * FROM tb_layanan_bayi as a, tb_bayi as b WHERE a.id_bayi = b.id_bayi AND a.tanggal_layanan_bayi='$tanggal'");

	//Cek Apakah ada data
	$cek = mysqli_affected_rows($koneksi);

	if ($cek > 0) {
		$response["kode"] = 1;
		$response["pesan"] = "berhasil";
		$response["data"]= array ();

		while ($ambil = mysqli_fetch_object($query)) {
			$F["berat_badan"]			= $ambil->berat_badan;
			$F["nama_bayi"]				= $ambil->nama_bayi;
			$F["tinggi_badan"]			= $ambil->tinggi_badan;
			$F["lingkar_kepala"]		= $ambil->lingkar_kepala;
			$F["umur_sekarang"]			= $ambil->umur_sekarang;
			$F["vitamin_a"]				= $ambil->vit_a;
			$F["oralit"]				= $ambil->oralit;
			$F["status_gizi"]			= $ambil->status_gizi;
			$F["tanggal_kunjungan_bayi"]= TanggalIndo($ambil->tanggal_layanan_bayi);

			array_push($response["data"],$F);
		}
	} else {
		$response["kode"] = 0;
		$response["pesan"] = "Data Tidak Tersedia";
	}

}else{
	$response['kode'] = 0;
	$response['pesan'] = "Tidak Ada Post Data";
}

echo json_encode($response);
mysqli_close($koneksi);
?>