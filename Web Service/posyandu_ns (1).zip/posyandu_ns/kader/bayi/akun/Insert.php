<?php

//Akses Database
require '../../../config/koneksi.php';

$response = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	
	//Mengambil Data
	$id_bayi			 = $_POST['id_bayi'];
	$username_pengunjung = $_POST['username_pengunjung'];
	$password_pengunjung = md5($_POST['password_pengunjung']);


	$cek_data = mysqli_num_rows(mysqli_query($koneksi,"SELECT * FROM tb_login_pengunjung WHERE id_bayi='$id_bayi'"));

	if ($cek_data>0) {
		$response["kode"] = 0;
		$response["pesan"] = "Akun sudah tersedia";
	} else {
		//Simpan ke Database
		$simpan = mysqli_query ($koneksi,"INSERT INTO tb_login_pengunjung 
					(username_pengunjung, password_pengunjung, id_bayi) VALUES 
					('$username_pengunjung','$password_pengunjung','$id_bayi')");

		//Cek Apakah Berhasil Menyimpan
		$cek = mysqli_affected_rows($koneksi);
		if ($cek > 0) {
			$response["kode"] = 1;
			$response["pesan"] = "Simpan Data Berhasil";
		}else{
			$response["kode"] = 0;
			$response["pesan"] = "Simpan Data Gagal";
		}
	}

}else{
	$response['kode'] = 0;
	$response['pesan'] = "Tidak Ada Post Data";
}

echo json_encode($response);
mysqli_close($koneksi);
?>