<?php

//Akses Database
require '../../../config/koneksi.php';

$response = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	
	//Mengambil Data
	$id_login_pengunjung = $_POST["id_login_pengunjung"];
	$username_pengunjung = $_POST['username_pengunjung'];
	$password_pengunjung = md5($_POST['password_pengunjung']);

	//Simpan ke Database
	$simpan = mysqli_query ($koneksi,"UPDATE tb_login_pengunjung SET
		username_pengunjung = '$username_pengunjung',
		password_pengunjung = '$password_pengunjung' WHERE 
		id_login_pengunjung = '$id_login_pengunjung'
		");

	//Cek Apakah Berhasil Menyimpan
	$cek = mysqli_affected_rows($koneksi);
	if ($cek > 0) {
		$response["kode"] = 1;
		$response["pesan"] = "Simpan Data Berhasil";
	}else{
		$response["kode"] = 0;
		$response["pesan"] = "Simpan Data Gagal";
	}

}else{
	$response['kode'] = 0;
	$response['pesan'] = "Tidak Ada Post Data";
}

echo json_encode($response);
mysqli_close($koneksi);
?>