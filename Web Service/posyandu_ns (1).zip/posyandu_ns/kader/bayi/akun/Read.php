<?php

//Akses Database
require '../../../config/koneksi.php';

function TanggalIndo($date){
	$BulanIndo = array("Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember");
 
	$tahun = substr($date, 0, 4);
	$bulan = substr($date, 5, 2);
	$tgl   = substr($date, 8, 2);
 
	$result = $tgl . " " . $BulanIndo[(int)$bulan-1] . " ". $tahun;		
	return($result);
}

$response = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	
	//Mengambil Data
	$id_bayi = $_POST['id_bayi'];

	//Simpan ke Database
	$query = mysqli_query($koneksi,"SELECT * FROM tb_login_pengunjung WHERE id_bayi='$id_bayi'");

	//Cek Apakah ada data
	$cek = mysqli_affected_rows($koneksi);

	if ($cek > 0) {
		$response["kode"] = 1;
		$response["pesan"] = "berhasil";
		$response["data"]= array ();

		while ($ambil = mysqli_fetch_object($query)) {
			$F["id_login_pengunjung"] = $ambil->id_login_pengunjung;
			$F["username_pengunjung"] = $ambil->username_pengunjung;
			$F["password_pengunjung"] = $ambil->password_pengunjung;
			$F["id_bayi"]			  = $ambil->id_bayi;

			array_push($response["data"],$F);
		}
	} else {
		$response["kode"] = 0;
		$response["pesan"] = "Data Tidak Tersedia";
	}

}else{
	$response['kode'] = 0;
	$response['pesan'] = "Tidak Ada Post Data";
}

echo json_encode($response);
mysqli_close($koneksi);
?>