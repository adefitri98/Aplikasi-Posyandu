<?php

//Akses Database
require '../../config/koneksi.php';

function Tanggal($date){
	$tahun = substr($date, 6, 4);
	$bulan = substr($date, 3, 2);
	$tgl   = substr($date, 0, 2);
 
	$result = $tahun . "-" . $bulan . "-". $tgl;		
	return($result);
}

$response = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	
	//Mengambil Data
	$nama_bayi = $_POST['nama_bayi'];
	$tgl_lahir = Tanggal($_POST['tgl_lahir']);
	$jk_bayi = $_POST['jk_bayi'];
	$nama_ibu = $_POST['nama_ibu'];
	$nama_ayah = $_POST['nama_ayah'];
	$kk_bayi = $_POST['kk_bayi'];
	$alamat_bayi = $_POST['alamat_bayi'];
	$anak_ke = $_POST['anak_ke'];
	$berat_lahir = $_POST['berat_lahir'];
	$sasaran = $_POST['sasaran'];

	//Simpan ke Database
	$simpan = mysqli_query ($koneksi,"INSERT INTO tb_bayi
		(nama_bayi,tgl_lahir,jk_bayi,nama_ibu,nama_ayah,kk_bayi,alamat_bayi,anak_ke,berat_lahir,sasaran) 
		VALUES ('$nama_bayi','$tgl_lahir','$jk_bayi','$nama_ibu','$nama_ayah','$kk_bayi','$alamat_bayi','$anak_ke','$berat_lahir','$sasaran')");

	//Cek Apakah Berhasil Menyimpan
	$cek = mysqli_affected_rows($koneksi);
	if ($cek > 0) {
		$response["kode"] = 1;
		$response["pesan"] = "Simpan Data Berhasil";
	}else{
		$response["kode"] = 0;
		$response["pesan"] = "Simpan Data Gagal";
	}

}else{
	$response['kode'] = 0;
	$response['pesan'] = "Tidak Ada Post Data";
}

echo json_encode($response);
mysqli_close($koneksi);
?>