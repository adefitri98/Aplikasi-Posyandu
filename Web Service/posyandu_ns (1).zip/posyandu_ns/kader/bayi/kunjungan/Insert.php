<?php

//Akses Database
require '../../../config/koneksi.php';

function TanggalIndo($date){
	$BulanIndo = array("Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember");
 
	$tahun = substr($date, 0, 4);
	$bulan = substr($date, 5, 2);
	$tgl   = substr($date, 8, 2);
 
	$result = $tgl . " " . $BulanIndo[(int)$bulan-1] . " ". $tahun;		
	return($result);
}

function Tanggal($date){
	$tahun = substr($date, 6, 4);
	$bulan = substr($date, 3, 2);
	$tgl   = substr($date, 0, 2);
 
	$result = $tahun . "-" . $bulan . "-". $tgl;		
	return($result);
}

$response = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	
	//Mengambil Data
	$id_bayi = $_POST['id_bayi'];
	//$tanggal_layanan_bayi = TanggalIndo($_POST['tanggal_kunjungan_bayi']);
	$tanggal_layanan_bayi = Tanggal($_POST['tanggal_kunjungan_bayi']);
	$berat_badan = $_POST['berat_badan'];
	$tinggi_badan = $_POST['tinggi_badan'];
	$lingkar_kepala = $_POST['lingkar_kepala'];
	$umur_sekarang = $_POST['umur_sekarang'];
	$vit_a = $_POST['vit_a'];
	$oralit = $_POST['oralit'];
	$status_gizi = $_POST['status_gizi'];

	//Simpan ke Database
	$simpan = mysqli_query ($koneksi,"INSERT INTO tb_layanan_bayi (id_bayi, tanggal_layanan_bayi,berat_badan, tinggi_badan, lingkar_kepala, umur_sekarang, vit_a, oralit, status_gizi) VALUES ('$id_bayi','$tanggal_layanan_bayi','$berat_badan','$tinggi_badan','$lingkar_kepala','$umur_sekarang', '$vit_a', '$oralit', '$status_gizi')");

	//Cek Apakah Berhasil Menyimpan
	$cek = mysqli_affected_rows($koneksi);
	if ($cek > 0) {
		$response["kode"] = 1;
		$response["pesan"] = "Simpan Data Berhasil";
	}else{
		$response["kode"] = 0;
		$response["pesan"] = "Simpan Data Gagal";
	}

}else{
	$response['kode'] = 0;
	$response['pesan'] = "Tidak Ada Post Data";
}

echo json_encode($response);
mysqli_close($koneksi);
?>