<?php

//Akses Database
require '../../../config/koneksi.php';

function Tanggal($date){
	$tahun = substr($date, 6, 4);
	$bulan = substr($date, 3, 2);
	$tgl   = substr($date, 0, 2);
 
	$result = $tahun . "-" . $bulan . "-". $tgl;		
	return($result);
}

$response = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	
	//Mengambil Data
	$id_layanan_bayi = $_POST['id_kunjungan_bayi'];
	$tanggal_layanan_bayi = Tanggal($_POST['tanggal_kunjungan_bayi']);
	$berat_badan = $_POST['berat_badan'];
	$tinggi_badan = $_POST['tinggi_badan'];
	$lingkar_kepala = $_POST['lingkar_kepala'];
	$umur_sekarang = $_POST['umur_sekarang'];
	$vit_a = $_POST['vit_a'];
	$oralit = $_POST['oralit'];
	$status_gizi = $_POST['status_gizi'];

	//Simpan ke Database
	$simpan = mysqli_query ($koneksi,"UPDATE tb_layanan_bayi SET
		tanggal_layanan_bayi    = '$tanggal_layanan_bayi',
		berat_badan 			= '$berat_badan',
		tinggi_badan			= '$tinggi_badan',
		lingkar_kepala 			= '$lingkar_kepala',
		umur_sekarang			= '$umur_sekarang',
		vit_a 					= '$vit_a',
		oralit					= '$oralit',
		status_gizi				= '$status_gizi' WHERE 
		id_layanan_bayi		    = '$id_layanan_bayi'
		");

	//Cek Apakah Berhasil Menyimpan
	$cek = mysqli_affected_rows($koneksi);
	if ($cek > 0) {
		$response["kode"] = 1;
		$response["pesan"] = "Simpan Data Berhasil";
	}else{
		$response["kode"] = 0;
		$response["pesan"] = "Simpan Data Gagal";
	}

}else{
	$response['kode'] = 0;
	$response['pesan'] = "Tidak Ada Post Data";
}

echo json_encode($response);
mysqli_close($koneksi);
?>