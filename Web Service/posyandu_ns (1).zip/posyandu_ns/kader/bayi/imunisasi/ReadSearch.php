<?php

//Akses Database
require '../../../config/koneksi.php';

function TanggalIndo($date){
	$BulanIndo = array("Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember");
 
	$tahun = substr($date, 0, 4);
	$bulan = substr($date, 5, 2);
	$tgl   = substr($date, 8, 2);
 
	$result = $tgl . " " . $BulanIndo[(int)$bulan-1] . " ". $tahun;		
	return($result);
}

function TanggalDate($tanggal){
	$tgl   = substr($tanggal, 0, 2);
	$bulan = substr($tanggal, 3, -5);
	$tahun = substr($tanggal, -4);

	if ($bulan == "Januari") { $bulanAngka = "01";
	} else if ($bulan=="Februari"){ $bulanAngka = "02";
	} else if ($bulan=="Maret"){ $bulanAngka = "03";
	} else if ($bulan=="April"){ $bulanAngka = "04";
	} else if ($bulan=="Mei"){ $bulanAngka = "05";
	} else if ($bulan=="Juni"){ $bulanAngka = "06";
	} else if ($bulan=="Juli"){ $bulanAngka = "07";
	} else if ($bulan=="Agustus"){ $bulanAngka = "08";
	} else if ($bulan=="September"){ $bulanAngka = "09";
	} else if ($bulan=="Oktober"){ $bulanAngka = "10";
	} else if ($bulan=="November"){ $bulanAngka = "11";
	} else{ $bulanAngka = "12"; }
 
	$result = $tahun . "-" . $bulanAngka . "-". $tgl;		
	return($result);
}

$response = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	
	//Mengambil Data
	$id_bayi = $_POST['id_bayi'];
	$search = TanggalDate($_POST['search']);

	//Simpan ke Database
	$query = mysqli_query($koneksi,"SELECT * FROM tb_imunisasi_bayi 
		WHERE id_bayi='$id_bayi' AND tanggal_imunisasi LIKE '%$search%' ORDER BY tanggal_imunisasi ASC");

	//Cek Apakah ada data
	$cek = mysqli_affected_rows($koneksi);

	if ($cek > 0) {
		$response["kode"] = 1;
		$response["pesan"] = "berhasil";
		$response["data"]= array ();

		while ($ambil = mysqli_fetch_object($query)) {
			$F["id_imunisasi"]		= $ambil->id_imunisasi;
			$F["jenis_imunisasi"]	= $ambil->jenis_imunisasi;
			$F["usia_pemberian"]	= $ambil->usia_pemberian;
			$F["tanggal"]			= $ambil->tanggal_imunisasi;
			$F["tanggal_imunisasi"]	= TanggalIndo($ambil->tanggal_imunisasi);
			$F["id_bayi"]			= $ambil->id_bayi;

			array_push($response["data"],$F);
		}
	} else {
		$response["kode"] = 0;
		$response["pesan"] = "Data Tidak Tersedia";
	}

}else{
	$response['kode'] = 0;
	$response['pesan'] = "Tidak Ada Post Data";
}

echo json_encode($response);
mysqli_close($koneksi);
?>