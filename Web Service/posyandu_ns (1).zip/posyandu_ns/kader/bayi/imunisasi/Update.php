<?php

//Akses Database
require '../../../config/koneksi.php';

function Tanggal($date){
	$tahun = substr($date, 6, 4);
	$bulan = substr($date, 3, 2);
	$tgl   = substr($date, 0, 2);
 
	$result = $tahun . "-" . $bulan . "-". $tgl;		
	return($result);
}

$response = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	
	//Mengambil Data
	$id_imunisasi 		= $_POST['id_imunisasi'];
	$tanggal_imunisasi	= Tanggal($_POST['tanggal_imunisasi']);
	$jenis_imunisasi	= $_POST['jenis_imunisasi'];
	$usia_pemberian		= $_POST['usia_pemberian'];

	//Simpan ke Database
	$simpan = mysqli_query ($koneksi,"UPDATE tb_imunisasi_bayi SET
		tanggal_imunisasi	= '$tanggal_imunisasi',
		jenis_imunisasi		= '$jenis_imunisasi',
		usia_pemberian		= '$usia_pemberian' WHERE 
		id_imunisasi		= '$id_imunisasi'
		");

	//Cek Apakah Berhasil Menyimpan
	$cek = mysqli_affected_rows($koneksi);
	if ($cek > 0) {
		$response["kode"] = 1;
		$response["pesan"] = "Simpan Data Berhasil";
	}else{
		$response["kode"] = 0;
		$response["pesan"] = "Simpan Data Gagal";
	}

}else{
	$response['kode'] = 0;
	$response['pesan'] = "Tidak Ada Post Data";
}

echo json_encode($response);
mysqli_close($koneksi);
?>