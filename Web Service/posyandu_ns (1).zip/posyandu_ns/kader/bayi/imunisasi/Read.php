<?php

//Akses Database
require '../../../config/koneksi.php';

function TanggalIndo($date){
	$BulanIndo = array("Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember");
 
	$tahun = substr($date, 0, 4);
	$bulan = substr($date, 5, 2);
	$tgl   = substr($date, 8, 2);
 
	$result = $tgl . " " . $BulanIndo[(int)$bulan-1] . " ". $tahun;		
	return($result);
}

function Tanggal($date){
 
	$tahun = substr($date, 0, 4);
	$bulan = substr($date, 5, 2);
	$tgl   = substr($date, 8, 2);
 
	$result = $tgl . "-" . $bulan . "-". $tahun;		
	return($result);
}

$response = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	
	//Mengambil Data
	$id_bayi = $_POST['id_bayi'];

	//Simpan ke Database
	$query = mysqli_query($koneksi,"SELECT * FROM tb_imunisasi_bayi WHERE id_bayi='$id_bayi' ORDER BY tanggal_imunisasi ASC");

	//Cek Apakah ada data
	$cek = mysqli_affected_rows($koneksi);

	if ($cek > 0) {
		$response["kode"] = 1;
		$response["pesan"] = "berhasil";
		$response["data"]= array ();

		while ($ambil = mysqli_fetch_object($query)) {
			$F["id_imunisasi"]		= $ambil->id_imunisasi;
			$F["jenis_imunisasi"]	= $ambil->jenis_imunisasi;
			$F["usia_pemberian"]	= $ambil->usia_pemberian;
			$F["tanggal"]			= Tanggal($ambil->tanggal_imunisasi);
			$F["tanggal_imunisasi"]	= TanggalIndo($ambil->tanggal_imunisasi);
			$F["id_bayi"]			= $ambil->id_bayi;

			array_push($response["data"],$F);
		}
	} else {
		$response["kode"] = 0;
		$response["pesan"] = "Data Tidak Tersedia";
	}

}else{
	$response['kode'] = 0;
	$response['pesan'] = "Tidak Ada Post Data";
}

echo json_encode($response);
mysqli_close($koneksi);
?>