<?php

//Akses Database
require '../../../config/koneksi.php';

function Tanggal($date){
	$tahun = substr($date, 6, 4);
	$bulan = substr($date, 3, 2);
	$tgl   = substr($date, 0, 2);
 
	$result = $tahun . "-" . $bulan . "-". $tgl;		
	return($result);
}

$response = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	

	//Mengambil Data
	$id_bayi			= $_POST['id_bayi'];
	$tanggal_imunisasi	= Tanggal($_POST['tanggal_imunisasi']);
	$jenis_imunisasi	= $_POST['jenis_imunisasi'];
	$usia_pemberian		= $_POST['usia_pemberian'];


	$query= mysqli_query($koneksi, "SELECT * FROM tb_imunisasi_bayi WHERE id_bayi='$id_bayi' AND jenis_imunisasi='$jenis_imunisasi'");
	$cek_query = mysqli_num_rows($query);

	if ($cek_query>0) {
		$response["kode"] = 0;
		$response["pesan"] = "Sudah Pernah Imunisasi"." ".$jenis_imunisasi;
		
	} else {
		//Simpan ke Database
		$simpan = mysqli_query ($koneksi,"INSERT INTO tb_imunisasi_bayi 
			(id_bayi, tanggal_imunisasi, jenis_imunisasi, usia_pemberian) VALUES 
			('$id_bayi','$tanggal_imunisasi','$jenis_imunisasi','$usia_pemberian')");

		//Cek Apakah Berhasil Menyimpan
		$cek = mysqli_affected_rows($koneksi);
		if ($cek > 0) {
			$response["kode"] = 1;
			$response["pesan"] = "Simpan Data Berhasil";
		}else{
			$response["kode"] = 0;
			$response["pesan"] = "Simpan Data Gagal";
		}
	}

}else{
	$response['kode'] = 0;
	$response['pesan'] = "Tidak Ada Post Data";
}

echo json_encode($response);
mysqli_close($koneksi);
?>