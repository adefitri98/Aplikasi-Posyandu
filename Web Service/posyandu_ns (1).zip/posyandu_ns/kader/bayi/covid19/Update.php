<?php

//Akses Database
require '../../../config/koneksi.php';

function Tanggal($date){
	$tahun = substr($date, 6, 4);
	$bulan = substr($date, 3, 2);
	$tgl   = substr($date, 0, 2);
 
	$result = $tahun . "-" . $bulan . "-". $tgl;		
	return($result);
}

$response = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	
	//Mengambil Data
	$id_covid			= $_POST["id_covid"];
	$tanggal_covid		= Tanggal($_POST['tanggal_covid']);
	$masker				= $_POST['masker'];
	$cuci_tangan		= $_POST['cuci_tangan'];
	$jaga_jarak			= $_POST['jaga_jarak'];
	$demam				= $_POST['demam'];
	$sesak_napas		= $_POST['sesak_napas'];
	$batuk				= $_POST['batuk'];
	$sakit_tenggorokan	= $_POST['sakit_tenggorokan'];

	//Simpan ke Database
	$simpan = mysqli_query ($koneksi,"UPDATE tb_covid19 SET
		tanggal_covid		= '$tanggal_covid',
		masker				= '$masker',
		cuci_tangan			= '$cuci_tangan',
		jaga_jarak			= '$jaga_jarak',
		demam				= '$demam',
		sesak_napas			= '$sesak_napas',
		batuk				= '$batuk',
		sakit_tenggorokan	= '$sakit_tenggorokan' WHERE 
		id_covid			= '$id_covid'
		");

	//Cek Apakah Berhasil Menyimpan
	$cek = mysqli_affected_rows($koneksi);
	if ($cek > 0) {
		$response["kode"] = 1;
		$response["pesan"] = "Simpan Data Berhasil";
	}else{
		$response["kode"] = 0;
		$response["pesan"] = "Simpan Data Gagal";
	}

}else{
	$response['kode'] = 0;
	$response['pesan'] = "Tidak Ada Post Data";
}

echo json_encode($response);
mysqli_close($koneksi);
?>