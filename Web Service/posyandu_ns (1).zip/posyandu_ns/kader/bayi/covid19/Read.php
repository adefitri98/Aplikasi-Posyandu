<?php

//Akses Database
require '../../../config/koneksi.php';

function TanggalIndo($date){
	$BulanIndo = array("Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember");
 
	$tahun = substr($date, 0, 4);
	$bulan = substr($date, 5, 2);
	$tgl   = substr($date, 8, 2);
 
	$result = $tgl . " " . $BulanIndo[(int)$bulan-1] . " ". $tahun;		
	return($result);
}

function Tanggal($date){
 
	$tahun = substr($date, 0, 4);
	$bulan = substr($date, 5, 2);
	$tgl   = substr($date, 8, 2);
 
	$result = $tgl . "-" . $bulan . "-". $tahun;		
	return($result);
}

$response = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	
	//Mengambil Data
	$id_bayi = $_POST['id_bayi'];

	//Simpan ke Database
	$query = mysqli_query($koneksi,"SELECT * FROM tb_covid19 WHERE id_bayi='$id_bayi' ORDER BY tanggal_covid ASC");

	//Cek Apakah ada data
	$cek = mysqli_affected_rows($koneksi);

	if ($cek > 0) {
		$response["kode"] = 1;
		$response["pesan"] = "berhasil";
		$response["data"]= array ();

		while ($ambil = mysqli_fetch_object($query)) {
			$F["id_covid"]			= $ambil->id_covid;
			$F["tanggal"]			= Tanggal($ambil->tanggal_covid);
			$F["tanggal_covid"]		= TanggalIndo($ambil->tanggal_covid);
			$F["masker"]			= $ambil->masker;
			$F["cuci_tangan"]		= $ambil->cuci_tangan;
			$F["jaga_jarak"]		= $ambil->jaga_jarak;
			$F["demam"]				= $ambil->demam;
			$F["sesak_napas"]		= $ambil->sesak_napas;
			$F["batuk"]				= $ambil->batuk;
			$F["sakit_tenggorokan"]	= $ambil->sakit_tenggorokan;
			$F["id_bayi"]			= $ambil->id_bayi;

			array_push($response["data"],$F);
		}
	} else {
		$response["kode"] = 0;
		$response["pesan"] = "Data Tidak Tersedia";
	}

}else{
	$response['kode'] = 0;
	$response['pesan'] = "Tidak Ada Post Data";
}

echo json_encode($response);
mysqli_close($koneksi);
?>