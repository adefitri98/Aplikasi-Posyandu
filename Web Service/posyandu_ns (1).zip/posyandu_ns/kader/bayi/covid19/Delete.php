<?php
require '../../../config/koneksi.php';

$response = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	
	$id_covid = $_POST["id_covid"];

	$hapus = mysqli_query($koneksi,"DELETE FROM tb_covid19 WHERE id_covid= '$id_covid'");
	$cek = mysqli_affected_rows($koneksi);

	if ($cek > 0) {
		$response["kode"] = 1;
		$response["pesan"] = "Data Berhasil Dihapus";
	}else{
		$response["kode"] = 0;
		$response["pesan"] = "Gagal Menghapus Data";
	}

}else{
	$response['kode'] = 0;
	$response['pesan'] = "Tidak Ada Hapus Data";
}

echo json_encode($response);
mysqli_close($koneksi);
?>