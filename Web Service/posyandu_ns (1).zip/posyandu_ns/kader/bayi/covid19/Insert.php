<?php

//Akses Database
require '../../../config/koneksi.php';

function Tanggal($date){
	$tahun = substr($date, 6, 4);
	$bulan = substr($date, 3, 2);
	$tgl   = substr($date, 0, 2);
 
	$result = $tahun . "-" . $bulan . "-". $tgl;		
	return($result);
}

$response = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	
	//Mengambil Data
	$id_bayi			= $_POST['id_bayi'];
	$tanggal_covid		= Tanggal($_POST['tanggal_covid']);
	$masker				= $_POST['masker'];
	$cuci_tangan		= $_POST['cuci_tangan'];
	$jaga_jarak			= $_POST['jaga_jarak'];
	$demam				= $_POST['demam'];
	$sesak_napas		= $_POST['sesak_napas'];
	$batuk				= $_POST['batuk'];
	$sakit_tenggorokan	= $_POST['sakit_tenggorokan'];

	//Simpan ke Database
	$simpan = mysqli_query ($koneksi,"INSERT INTO tb_covid19 
		(id_bayi, tanggal_covid, masker, cuci_tangan, jaga_jarak, demam, sesak_napas, batuk, sakit_tenggorokan) VALUES 
		('$id_bayi','$tanggal_covid','$masker','$cuci_tangan','$jaga_jarak','$demam','$sesak_napas','$batuk','$sakit_tenggorokan')");

	//Cek Apakah Berhasil Menyimpan
	$cek = mysqli_affected_rows($koneksi);
	if ($cek > 0) {
		$response["kode"] = 1;
		$response["pesan"] = "Simpan Data Berhasil";
	}else{
		$response["kode"] = 0;
		$response["pesan"] = "Simpan Data Gagal";
	}

}else{
	$response['kode'] = 0;
	$response['pesan'] = "Tidak Ada Post Data";
}

echo json_encode($response);
mysqli_close($koneksi);
?>