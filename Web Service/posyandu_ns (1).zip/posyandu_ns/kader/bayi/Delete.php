<?php
require '../../config/koneksi.php';

$response = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	
	$id_bayi = $_POST["id_bayi"];

	$hapus = mysqli_query($koneksi,"DELETE FROM tb_kunjungan_bayi WHERE id_bayi = '$id_bayi'");
	$hapus2 = mysqli_query($koneksi,"DELETE FROM tb_imunisasi_bayi WHERE id_bayi = '$id_bayi'");
	$hapus3 = mysqli_query($koneksi,"DELETE FROM tb_covid19 WHERE id_bayi = '$id_bayi'");
	$hapus4 = mysqli_query($koneksi,"DELETE FROM tb_login_pengunjung WHERE id_bayi = '$id_bayi'");
	$hapus5 = mysqli_query($koneksi,"DELETE FROM tb_bayi WHERE id_bayi = '$id_bayi'");
	
	if ($hapus5) {
		$response["kode"] = 1;
		$response["pesan"] = "Data Berhasil Dihapus";
	}else{
		$response["kode"] = 0;
		$response["pesan"] = "Gagal Menghapus Data";
	}

}else{
	$response['kode'] = 0;
	$response['pesan'] = "Tidak Ada Hapus Data";
}

echo json_encode($response);
mysqli_close($koneksi);
?>