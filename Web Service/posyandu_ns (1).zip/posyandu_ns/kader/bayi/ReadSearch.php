<?php
require '../../config/koneksi.php';

function TanggalIndo($date){
	$BulanIndo = array("Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember");
 
	$tahun = substr($date, 0, 4);
	$bulan = substr($date, 5, 2);
	$tgl   = substr($date, 8, 2);
 
	$result = $tgl . " " . $BulanIndo[(int)$bulan-1] . " ". $tahun;		
	return($result);
}

function Tanggal($date){
 
	$tahun = substr($date, 0, 4);
	$bulan = substr($date, 5, 2);
	$tgl   = substr($date, 8, 2);
 
	$result = $tgl . "-" . $bulan . "-". $tahun;		
	return($result);
}


//Mengambil seluruh data pada tabel

$search = $_POST['search'];

$query = mysqli_query($koneksi,"SELECT * FROM tb_bayi WHERE nama_bayi LIKE '%$search%' ORDER BY nama_bayi ASC");

//Cek Apakah ada data
$cek = mysqli_affected_rows($koneksi);

if ($cek > 0) {
	$response["kode"] = 1;
	$response["pesan"] = "berhasil";
	$response["data"]= array ();

	while ($ambil = mysqli_fetch_object($query)) {
		$F["id_bayi"]=$ambil->id_bayi;
		$F["nama_bayi"]=$ambil->nama_bayi;
		$F["tgl_lahir"]=TanggalIndo($ambil->tgl_lahir);
		$F["tanggal"]=Tanggal($ambil->tgl_lahir);
		$F["jk_bayi"]=$ambil->jk_bayi;
		$F["nama_ibu"]=$ambil->nama_ibu;
		$F["nama_ayah"]=$ambil->nama_ayah;
		$F["kk_bayi"]=$ambil->kk_bayi;
		$F["alamat_bayi"]=$ambil->alamat_bayi;
		$F["anak_ke"]=$ambil->anak_ke;
		$F["berat_lahir"]=$ambil->berat_lahir;
		$F["sasaran"]=$ambil->sasaran;

		array_push($response["data"],$F);
	}
} else {
	$response["kode"] = 0;
	$response["pesan"] = "Data Tidak Tersedia";
}

echo json_encode($response);
mysqli_close($koneksi);

?>