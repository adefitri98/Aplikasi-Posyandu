<?php

//Akses Database
require '../../config/koneksi.php';

function Tanggal($date){
	$tahun = substr($date, 6, 4);
	$bulan = substr($date, 3, 2);
	$tgl   = substr($date, 0, 2);
 
	$result = $tahun . "-" . $bulan . "-". $tgl;		
	return($result);
}

$response = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	
	//Mengambil Data
	$id_jadwal = $_POST["id_jadwal"];
	$tgl_jadwal = Tanggal($_POST["tgl_jadwal"]);
	$waktu_jadwal = $_POST["waktu_jadwal"];
	$acara_jadwal = $_POST["acara_jadwal"];

	//Simpan ke Database
	$simpan = mysqli_query ($koneksi,"UPDATE tb_jadwal_posyandu SET
		tgl_jadwal = '$tgl_jadwal',
		waktu_jadwal = '$waktu_jadwal',
		acara_jadwal = '$acara_jadwal'
		WHERE id_jadwal ='$id_jadwal'
		");

	//Cek Apakah Berhasil Menyimpan
	$cek = mysqli_affected_rows($koneksi);
	if ($cek > 0) {
		$response["kode"] = 1;
		$response["pesan"] = "Simpan Data Berhasil";
	}else{
		$response["kode"] = 0;
		$response["pesan"] = "Simpan Data Gagal";
	}

}else{
	$response['kode'] = 0;
	$response['pesan'] = "Tidak Ada Post Data";
}

echo json_encode($response);
mysqli_close($koneksi);
?>