<?php
require '../../config/koneksi.php';

function TanggalIndo($date){
	$BulanIndo = array("Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember");
 
	$tahun = substr($date, 0, 4);
	$bulan = substr($date, 5, 2);
	$tgl   = substr($date, 8, 2);
 
	$result = $tgl . " " . $BulanIndo[(int)$bulan-1] . " ". $tahun;		
	return($result);
}

function Tanggal($date){

	$tgl   = substr($date, 8, 2);
 
	$result = $tgl;		
	return($result);
}

function Bulan($date){
	$BulanIndo = array("Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember");
 
	$bulan = substr($date, 5, 2);
 
	$result = $BulanIndo[(int)$bulan-1];		
	return($result);
}

function TanggalBalik($date){
 
	$tahun = substr($date, 0, 4);
	$bulan = substr($date, 5, 2);
	$tgl   = substr($date, 8, 2);
 
	$result = $tgl . "-" . $bulan . "-". $tahun;		
	return($result);
}



//Mengambil seluruh data pada tabel
$query = mysqli_query($koneksi,"SELECT * FROM tb_jadwal_posyandu ORDER BY tgl_jadwal ASC");

//Cek Apakah ada data
$cek = mysqli_affected_rows($koneksi);

if ($cek > 0) {
	$response["kode"] = 1;
	$response["pesan"] = "Data Tersedia";
	$response["data"]= array ();

	while ($ambil = mysqli_fetch_object($query)) {
		$F["id_jadwal"]=$ambil->id_jadwal;
		$F["tgl"]=Tanggal($ambil->tgl_jadwal);
		$F["bln"]=Bulan($ambil->tgl_jadwal);
		$F["waktu_jadwal"]=$ambil->waktu_jadwal;
		$F["acara_jadwal"]=$ambil->acara_jadwal;
		$F["tanggal"]=TanggalBalik($ambil->tgl_jadwal);

		array_push($response["data"],$F);
	}
} else {
	$response["kode"] = 0;
	$response["pesan"] = "Data Tidak Tersedia";
}

echo json_encode($response);
mysqli_close($koneksi);

?>