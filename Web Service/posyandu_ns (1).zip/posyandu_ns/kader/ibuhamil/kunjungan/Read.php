<?php

//Akses Database
require '../../../config/koneksi.php';

function TanggalIndo($date){
	$BulanIndo = array("Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember");
 
	$tahun = substr($date, 0, 4);
	$bulan = substr($date, 5, 2);
	$tgl   = substr($date, 8, 2);
 
	$result = $tgl . " " . $BulanIndo[(int)$bulan-1] . " ". $tahun;		
	return($result);
}

function Tanggal($date){
 
	$tahun = substr($date, 0, 4);
	$bulan = substr($date, 5, 2);
	$tgl   = substr($date, 8, 2);
 
	$result = $tgl . "-" . $bulan . "-". $tahun;		
	return($result);
}

$response = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	
	//Mengambil Data
	$id_ibu_hamil = $_POST['id_ibu_hamil'];

	//Simpan ke Database
	$query = mysqli_query($koneksi,"SELECT * FROM tb_layanan_ibu_hamil WHERE id_ibu_hamil='$id_ibu_hamil' ORDER BY tanggal_layanan ASC");

	//Cek Apakah ada data
	$cek = mysqli_affected_rows($koneksi);

	if ($cek > 0) {
		$response["kode"] = 1;
		$response["pesan"] = "berhasil";
		$response["data"]= array ();

		while ($ambil = mysqli_fetch_object($query)) {
			$F["id_kunjungan_ibu_hamil"]=$ambil->id_layanan_ibu_hamil;
			$F["hasil_penimbangan"]=$ambil->hasil_penimbangan;
			$F["pmt_pemulihan"]=$ambil->pmt_pemulihan;
			$F["umur_kehamilan"]=$ambil->umur_kehamilan;
		$F["lingkar_lengan"]=$ambil->lingkar_lengan;
			$F["tanggal_kunjungan"]=TanggalIndo($ambil->tanggal_layanan);
			$F["id_ibu_hamil"]=$ambil->id_ibu_hamil;
			$F["tanggal"]=Tanggal($ambil->tanggal_layanan);

			array_push($response["data"],$F);
		}
	} else {
		$response["kode"] = 0;
		$response["pesan"] = "Data Tidak Tersedia";
	}

}else{
	$response['kode'] = 0;
	$response['pesan'] = "Tidak Ada Post Data";
}

echo json_encode($response);
mysqli_close($koneksi);
?>