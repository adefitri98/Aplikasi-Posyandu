<?php

//Akses Database
require '../../../config/koneksi.php';

function Tanggal($date){
	$tahun = substr($date, 6, 4);
	$bulan = substr($date, 3, 2);
	$tgl   = substr($date, 0, 2);
 
	$result = $tahun . "-" . $bulan . "-". $tgl;		
	return($result);
}

$response = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	
	//Mengambil Data
	$id_layanan_ibu_hamil = $_POST['id_kunjungan_ibu_hamil'];
	$hasil_penimbangan = $_POST['hasil_penimbangan'];
	$pmt_pemulihan = $_POST['pmt_pemulihan'];
	$umur_kehamilan = $_POST['umur_kehamilan'];
	$lingkar_lengan = $_POST['lingkar_lengan'];
	$tanggal_layanan = Tanggal($_POST['tanggal_kunjungan']);

	//Simpan ke Database
	$simpan = mysqli_query ($koneksi,"UPDATE tb_layanan_ibu_hamil SET
		hasil_penimbangan 		= '$hasil_penimbangan',
		pmt_pemulihan 			= '$pmt_pemulihan',
		umur_kehamilan          = '$umur_kehamilan',
		lingkar_lengan          = '$lingkar_lengan',
		tanggal_layanan		    = '$tanggal_layanan' WHERE 
		id_layanan_ibu_hamil	= '$id_layanan_ibu_hamil'
		");

	//Cek Apakah Berhasil Menyimpan
	$cek = mysqli_affected_rows($koneksi);
	if ($cek > 0) {
		$response["kode"] = 1;
		$response["pesan"] = "Simpan Data Berhasil";
	}else{
		$response["kode"] = 0;
		$response["pesan"] = "Simpan Data Gagal";
	}

}else{
	$response['kode'] = 0;
	$response['pesan'] = "Tidak Ada Post Data";
}

echo json_encode($response);
mysqli_close($koneksi);
?>