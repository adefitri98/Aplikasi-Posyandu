<?php
require '../../config/koneksi.php';

function TanggalIndo($date){
	$BulanIndo = array("Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember");
 
	$tahun = substr($date, 0, 4);
	$bulan = substr($date, 5, 2);
	$tgl   = substr($date, 8, 2);
 
	$result = $tgl . " " . $BulanIndo[(int)$bulan-1] . " ". $tahun;		
	return($result);
}

function Tanggal($date){
 
	$tahun = substr($date, 0, 4);
	$bulan = substr($date, 5, 2);
	$tgl   = substr($date, 8, 2);
 
	$result = $tgl . "-" . $bulan . "-". $tahun;		
	return($result);
}

$search = $_POST['search'];

//Mengambil seluruh data pada tabel
$query = mysqli_query($koneksi,"SELECT * FROM tb_ibu_hamil WHERE nama_ibu_hamil LIKE '%$search%' ORDER BY nama_ibu_hamil ASC");

//Cek Apakah ada data
$cek = mysqli_affected_rows($koneksi);

if ($cek > 0) {
	$response["kode"] = 1;
	$response["pesan"] = "berhasil";
	$response["data"]= array ();

	while ($ambil = mysqli_fetch_object($query)) {
		$F["id_ibu_hamil"]=$ambil->id_ibu_hamil;
		$F["nama_ibu_hamil"]=$ambil->nama_ibu_hamil;
		$F["nama_suami"]=$ambil->nama_suami;
		$F["hamil_ke"]=$ambil->hamil_ke;
		$F["tanggal_pendaftaran"]=TanggalIndo($ambil->tanggal_pendaftaran);
		$F["tanggal"]=Tanggal($ambil->tanggal_pendaftaran);

		array_push($response["data"],$F);
	}
} else {
	$response["kode"] = 0;
	$response["pesan"] = "Data Tidak Tersedia";
}

echo json_encode($response);
mysqli_close($koneksi);

?>