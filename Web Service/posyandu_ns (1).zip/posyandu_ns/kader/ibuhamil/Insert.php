<?php

//Akses Database
require '../../config/koneksi.php';

function Tanggal($date){
	$tahun = substr($date, 6, 4);
	$bulan = substr($date, 3, 2);
	$tgl   = substr($date, 0, 2);
 
	$result = $tahun . "-" . $bulan . "-". $tgl;		
	return($result);
}

$response = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	
	//Mengambil Data
	$nama_ibu_hamil = $_POST['nama_ibu_hamil'];
	$nama_suami = $_POST['nama_suami'];
	$hamil_ke = $_POST['hamil_ke'];
	$tanggal_pendaftaran = Tanggal($_POST['tanggal_pendaftaran']);

	//Simpan ke Database
	$simpan = mysqli_query ($koneksi,"INSERT INTO tb_ibu_hamil
		(nama_ibu_hamil,nama_suami,hamil_ke,tanggal_pendaftaran) 
		VALUES 
		('$nama_ibu_hamil','$nama_suami','$hamil_ke','$tanggal_pendaftaran')");

	//Cek Apakah Berhasil Menyimpan
	$cek = mysqli_affected_rows($koneksi);
	if ($cek > 0) {
		$response["kode"] = 1;
		$response["pesan"] = "Simpan Data Berhasil";
	}else{
		$response["kode"] = 0;
		$response["pesan"] = "Simpan Data Gagal";
	}

}else{
	$response['kode'] = 0;
	$response['pesan'] = "Tidak Ada Post Data";
}

echo json_encode($response);
mysqli_close($koneksi);
?>