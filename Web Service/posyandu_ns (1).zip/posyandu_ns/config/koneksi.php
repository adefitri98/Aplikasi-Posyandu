<?php
$host = "localhost";   //Host
$username = "posyand6";    //User
$password = "*eBY!lHg7639lC"; //Password
$database = "posyand6_posyandu_ns";     // Nama Database
 
//Membuat Koneksi dengan mysqli 
$koneksi = new mysqli($host, $username, $password, $database);
 
//Jika ada Eror Eksekusi
//Akan Menampilkan Pesan Gagal
if ($koneksi->connect_error) {
    die("Gagal Konek Database: " . $koneksi->connect_error);
}
?>