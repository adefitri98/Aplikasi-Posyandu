<?php

//Akses Database
require '../config/koneksi.php';

$response = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	
	//Mengambil Data
	$username= $_POST['username'];
	$password = md5($_POST['password']);
	$jabatan = $_POST['level'];

	//Cek ke Database
	$ceklogin = mysqli_query ($koneksi,"SELECT * FROM tb_login_petugas as a, tb_petugas as b 
		WHERE 
		a.id_petugas = b.id_petugas &&
		a.username_petugas = '$username' &&
		a.password_petugas = '$password' && 
		b.jabatan = '$jabatan'
		");

	//Cek Apakah Berhasil Menyimpan
	$cek = mysqli_affected_rows($koneksi);

	if ($cek > 0) {

		$response["kode"] = 1;
		$response["pesan"] = "Login Berhasil";
		$response["data"]= array ();
		while ($ambil = mysqli_fetch_object($ceklogin)) {
			$F["id_login_petugas"]=$ambil->id_login_petugas;
			$F["nama_petugas"]=$ambil->nama_petugas;
			$F["username"]=$ambil->username_petugas;
			$F["level"]=$ambil->jabatan;

			array_push($response["data"],$F);
		}
	} else {
		$response["kode"] = 0;
		$response["pesan"] = "Data Tidak Tersedia";
	}

}else{
	$response['kode'] = 0;
	$response['pesan'] = "Tidak Ada Post Data";
}

echo json_encode($response);
mysqli_close($koneksi);
?>