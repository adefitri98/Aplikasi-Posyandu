<?php

//Akses Database
require '../config/koneksi.php';

$response = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	
	//Mengambil Data
	$username_pengunjung = $_POST['username_pengunjung'];
	$password_pengunjung = md5($_POST['password_pengunjung']);

	//Cek ke Database
	$ceklogin = mysqli_query ($koneksi,"SELECT * FROM tb_login_pengunjung WHERE 
		username_pengunjung = '$username_pengunjung' AND
		password_pengunjung = '$password_pengunjung'");

	//Cek Apakah Berhasil Menyimpan
	$cek = mysqli_affected_rows($koneksi);

	if ($cek > 0) {
		$response["kode"] = 1;
		$response["pesan"] = "Login Berhasil";
		$response["data"]= array ();
		while ($ambil = mysqli_fetch_object($ceklogin)) {
			$F["id_login_pengunjung"]=$ambil->id_login_pengunjung;
			$F["username_pengunjung"]=$ambil->username_pengunjung;
			$F["password_pengunjung"]=$ambil->password_pengunjung;
			$F["id_bayi2"]=$ambil->id_bayi;

			array_push($response["data"],$F);
		}
	} else {
		$response["kode"] = 0;
		$response["pesan"] = "Data Tidak Tersedia";
	}

}else{
	$response['kode'] = 0;
	$response['pesan'] = "Tidak Ada Post Data";
}

echo json_encode($response);
mysqli_close($koneksi);
?>