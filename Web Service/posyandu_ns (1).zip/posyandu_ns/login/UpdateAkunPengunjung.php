<?php

//Akses Database
require '../config/koneksi.php';

$response = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	
	//Mengambil Data
	$id_login_pengunjung = $_POST["id_login_pengunjung"];
	$username_pengunjung = $_POST['username_pengunjung'];
	$password_lama = md5($_POST['password_lama']);
	$password_baru = md5($_POST['password_baru']);

	//Simpan ke Database
	$cek = mysqli_query ($koneksi,"SELECT * FROM tb_login_pengunjung WHERE id_login_pengunjung='$id_login_pengunjung'");
	$ambil = mysqli_fetch_assoc($cek);
	if ($ambil['password_pengunjung'] == $password_lama) {

		//Simpan Perubahan ke Database
		$simpan = mysqli_query ($koneksi,"UPDATE tb_login_pengunjung SET
			username_pengunjung	= '$username_pengunjung',
			password_pengunjung	= '$password_baru'
			WHERE id_login_pengunjung ='$id_login_pengunjung'
			");
		if ($simpan) {
			$response["kode"] = 1;
			$response["pesan"] = "Berhasil";
		}
	} else {
		$response["kode"] = 0;
		$response["pesan"] = "Password Lama Salah";
	}

}else{
	$response['kode'] = 0;
	$response['pesan'] = "Tidak Ada Post Data";
}

echo json_encode($response);
mysqli_close($koneksi);
?>