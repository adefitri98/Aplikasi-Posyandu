<?php

//Akses Database
require '../config/koneksi.php';

$response = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	
	//Mengambil Data
	$id_login_petugas = $_POST['id_login_petugas'];
	$nama_petugas = $_POST['nama_petugas'];
	$username_petugas = $_POST['username_petugas'];
	$password_baru = md5($_POST['password_baru']);

	//Simpan ke Database
	$simpan = mysqli_query ($koneksi,"UPDATE tb_login_petugas as a, tb_petugas as b 
		SET
			b.nama_petugas		= '$nama_petugas',
			a.username_petugas	= '$username_petugas',
			a.password_petugas	= '$password_baru'
			WHERE a.id_petugas=b.id_petugas && a.id_login_petugas ='$id_login_petugas'");
	$cek = mysqli_affected_rows($koneksi);

	if ($cek > 0) {
		$response["kode"] = 1;
		$response["pesan"] = "Berhasil";
	} else {
		$response["kode"] = 0;
		$response["pesan"] = "Gagal";
	}

}else{
	$response['kode'] = 0;
	$response['pesan'] = "Tidak Ada Post Data";
}

echo json_encode($response);
mysqli_close($koneksi);
?>